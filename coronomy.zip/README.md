[![PyPI pyversions](https://img.shields.io/pypi/pyversions/ansicolortags.svg)](https://pypi.python.org/pypi/ansicolortags/)
[![GitHub license](https://img.shields.io/github/license/Naereen/StrapDown.js.svg)](https://github.com/Naereen/StrapDown.js/blob/master/LICENSE)


## Coronomy
Code the Curve submission

www.coronomy.online

## Deploy on Heroku (free)
First, edit the app.json and replace the value of the `repository`:
```
"repository": "https://github.com/cviaai/coronomy"
```
with the URL to the forked repository.

Then click on the button:

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
